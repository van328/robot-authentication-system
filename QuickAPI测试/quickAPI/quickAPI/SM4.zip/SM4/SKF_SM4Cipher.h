//
//  SKF_SM4Cipher.h
//  quickAPI
//
//  Created by SecureChip on 2018/2/6.
//  Copyright © 2018年 IIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CipherInterface.h"

@interface SKF_SM4Cipher : NSObject<CipherInterface>

@end
