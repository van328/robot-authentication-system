//
//  SKF_SM3Digest.h
//  quickAPI
//
//  Created by SecureChip on 2018/1/30.
//  Copyright © 2018年 IIE. All rights reserved.
//

#import "MessageDigest.h"
//#import "DigestInterface.h"
@interface SKF_SM3Digest : MessageDigest

@end
